import java.util.Random;
public class PriorityQueueSimulatorTester {
	public static void main(String[] args) {
		Random rand = new Random();
		int maxNumberOfJobs =100;
		UnsortedPQ unsortedPQ = new UnsortedPQ(maxNumberOfJobs);
		Job[] jobsInputArray = new Job[maxNumberOfJobs];
		 int currentTime = 0;
		 int numbOfPriorityChange = 0;
		 int totalWaittime=0;
		for (int i=0; i<jobsInputArray.length;i++) {
			long a = 0;
			int length = rand.nextInt(70)+1;
			int priority = rand.nextInt(40)+1;
			jobsInputArray[i] = new Job("Job_"+(i+1)+"",length,length,priority,priority,a,a,a);
			
		}
		for(int i = 0;i<jobsInputArray.length;i++) {
			
			unsortedPQ.insert(jobsInputArray[i]);
			jobsInputArray[i].entryTime= i+1;
			currentTime++;
		}
		int terminated = 0;
		while(!unsortedPQ.isEmpty()) {
			
			currentTime++;
			Job Jobcheck = unsortedPQ.removeMin();
			System.out.println("Now executing "+ Jobcheck.jobName +". Job length: "+Jobcheck.jobLength+ ". Current remaining length: "+ Jobcheck.currentJobLength+ " Initial priority: " +Jobcheck.jobPriority+"; Current priority: "+Jobcheck.finalPriority);
			Jobcheck.currentJobLength--;
			
			if(Jobcheck.currentJobLength>0) {
				Jobcheck.entryTime = currentTime;
				unsortedPQ.insert(Jobcheck);
				currentTime++;
			}
			else {
				terminated++;
				Jobcheck.waitTime = currentTime-  Jobcheck.entryTime ;
				totalWaittime += Jobcheck.waitTime;
				Jobcheck.endTime= currentTime;
				
				if(terminated %30 ==0) {
					currentTime++;
					unsortedPQ.highestEntry().setFinalPriority(1); 
					numbOfPriorityChange++;
					
				}
			}
			
				
			
		}
		System.out.println("Current system time (cycles): " +currentTime);
		System.out.println("Total number of jobs executed: " +terminated);
		System.out.println("Average process waiting time: " +totalWaittime/terminated);
		System.out.println("Total number of priority changes: " +numbOfPriorityChange);
	}
}
